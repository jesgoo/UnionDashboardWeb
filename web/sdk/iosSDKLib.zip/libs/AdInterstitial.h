//
//  AdInterstitial.h
//  JesgooMobAdSdk
//
//  Created by zhangliang on 14-1-20.
//  Copyright (c) 2014年 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class AdInterstitial;

@protocol AdInterstitialDelegate <NSObject>
@required
/**
 *  广告预加载展示失败回调
 */
- (void)interstitialFailed:(NSString *)reason;
/**
 *  广告展示时的回调
 */
- (void)interstitialShowed;
/**
 *  广告展示被用户点击时的回调
 */
- (void)interstitialClicked;

@end

@interface AdInterstitial : NSObject
- (instancetype)initWithAppId:(NSString *)appId adSlotsId:(NSString *)adSlotsId  listener:(id<AdInterstitialDelegate>)listener;
/**
 *  委托
 */
@property (nonatomic ,retain) id<AdInterstitialDelegate> delegate;


/**
 *  展示插屏广告
 */
- (void)showInterstial:(UIViewController *)rootViewController;

@end
