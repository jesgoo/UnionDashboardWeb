//
//  AdNative.h
//  JesgooMobAdSdk
//
//  Created by 张亮 on 15/8/18.
//  Copyright (c) 2015年 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class AdNative;

@protocol AdNativeDelegate <NSObject>
typedef enum : NSInteger {
    ALL = 0 ,
    TEXT = 1,//只要文本广告,可能包含广告logo
    IMAGE = 2,//只要图片广告

} StyleType;

@required
/**
 *  广告预加载成功回调
 */
- (void)nativeAdsLoaded:(AdNative *)nativeAd;
/**
 *  广告请求失败
 */
- (void)nativeAdsFailed:(NSString *)reason;

@end

@interface AdNative : NSObject
//包含图片广告和文字广告
- (instancetype)initWithAppId:(NSString *)appId adSlotsId:(NSString *)adSlotsId listener:(id<AdNativeDelegate>)listener forStyleType:(StyleType)styelType;

/**
 *  委托
 */
@property (nonatomic ,retain) id<AdNativeDelegate> delegate;
/**
 *  广告展示时需要被主动调用
 */
- (void)nativeAdsShow;
/**
 *  广告点击时需要被主动调用
 */
- (void)nativeAdsClick;

/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告id
 */
- (NSString*)getId;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告发帖人账户名称
 */

- (NSString*)getAccount;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告title
 */
- (NSString*)getTitle;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告description
 */
- (NSString*)getDesc1;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告imgUrl
 */
- (NSString*)getImgUrl;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,获取广告logoUrl
 */
- (NSString*)getLogoUrl;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,当有imgUrl时，获取图片宽
 */
- (int) getWidth;
/**
 * 广告获取后（nativeAdsLoaded被调用后）,当有imgUrl时，获取图片高
 */
- (int) getHeight;

+ (AdNative*) getAdNativeById:(NSString *) adid;

@end
