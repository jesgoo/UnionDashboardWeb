

#import <UIKit/UIKit.h>

@class AdView;

@protocol AdViewDelegate <NSObject>
@required

/**
 *  广告载入失败
 */
-(void) adFailed:(NSString *)reason;

/**
 *  本次广告展示成功时的回调
 */
-(void) adViewShowed;

/**
 *  本次广告展示被用户点击时的回调
 */
-(void) adViewClicked;
@end


@interface AdView : UIView
/**
 *  委托对象
 */
@property (nonatomic ,strong) id<AdViewDelegate>  delegate;
- (instancetype) initWithAppId:(NSString *)appId adSlotsId:(NSString *)adSlotsId frame:(CGRect)frame  listener:(id<AdViewDelegate>)listener;
@end




