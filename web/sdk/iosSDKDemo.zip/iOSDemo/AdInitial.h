//
//  AdInitial.h
//  JesgooMobAdSdk
//
//  Created by 张亮 on 15/8/21.
//  Copyright (c) 2015年 Will. All rights reserved.
//

//
//  AdInterstitial.h
//  JesgooMobAdSdk
//
//  Created by dengjinxiang on 15-1-10.
//  Copyright (c) 2015年 Will. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class AdInitial;

@protocol AdInitialDelegate <NSObject>
@required
/**
 *  广告展示时的回调
 */
- (void)initialFailed:(NSString *)reason;

/**
 *  广告展示时的回调
 */
- (void)initialShowed;
/**
 *  广告展示被用户点击时的回调
 */
- (void) initialClicked;

@end

@interface AdInitial : NSObject
- (instancetype)initWithAppId:(NSString *)appId adSlotsId:(NSString *)adSlotsId  controller:(UIViewController*) rootViewController listener:(id<AdInitialDelegate>)listener;

/**
 *  委托
 */
@property (nonatomic ,retain) id<AdInitialDelegate> delegate;

@end

