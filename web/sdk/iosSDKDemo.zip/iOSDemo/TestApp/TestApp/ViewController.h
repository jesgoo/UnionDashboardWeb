//
//  ViewController.h
//  TestApp
//
//  Created by Bolee on 11/4/14.
//  Copyright (c) 2014 Will. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdView.h"
#import "AdInterstitial.h"
#import "AdNative.h"
#import "AdInitial.h"

@interface ViewController : UIViewController<AdViewDelegate,AdNativeDelegate,AdInterstitialDelegate,AdInitialDelegate>
@property (nonatomic, strong)AdView *adView;
@property (nonatomic, strong)AdInterstitial *adInterstitial;
@property (nonatomic, strong)AdNative *adNative;
@property (nonatomic, strong)AdInitial *adInitial;
@end

