//
//  KCCutomCellViewController.m
//  UITableView
//
//  Created by Kenshin Cui on 14-3-1.
//  Copyright (c) 2014年 Kenshin Cui. All rights reserved.
//

#import "InfoCellViewController.h"
#import "ItemInfo.h"
#import "InfoTableViewCell.h"
#import "AdNative.h"

@interface InfoCellViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>{
    UITableView *_tableView;
    NSMutableArray *_status;
    NSMutableArray *_statusCells;//存储cell，用于计算高度
}


@end
@implementation InfoCellViewController
-(void) insertCell:(ItemInfo*) status at:(int)index{
    [_status insertObject:status atIndex:index];
    InfoTableViewCell *cell=[[InfoTableViewCell alloc]init];
    [_statusCells insertObject:cell atIndex:index];
    [_tableView reloadData];
}
-(void) clickLeftButton
{
    [_previousWindow makeKeyAndVisible];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //初始化数据
    [self initData];
    CGSize scrrenSize = [[UIScreen mainScreen] bounds].size;
    CGSize statusBarSize = [[UIApplication sharedApplication] statusBarFrame].size;

    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, self.view.bounds.origin.y+44-statusBarSize.height,scrrenSize.width,scrrenSize.height-44 )  style:UITableViewStyleGrouped];
    _tableView.dataSource=self;
    _tableView.delegate=self;

    [self.view addSubview:_tableView];
    
    UINavigationBar *navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0, statusBarSize.height, scrrenSize.width, 44)];
    UINavigationItem *navItem = [[UINavigationItem alloc] initWithTitle:nil];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:self action:@selector(clickLeftButton)];
    [navBar pushNavigationItem:navItem animated:NO];
    [navItem setLeftBarButtonItem:leftButton];
    [self.view addSubview:navBar];
    
}

#pragma mark 加载数据
-(void)initData{
    NSString *path=[[NSBundle mainBundle] pathForResource:@"StatusInfo" ofType:@"plist"];
    NSArray *array=[NSArray arrayWithContentsOfFile:path];
    _status=[[NSMutableArray alloc]init];
    _statusCells=[[NSMutableArray alloc]init];
    [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        ItemInfo* status = [ItemInfo statusWithDictionary:obj];
        [_status addObject:status];
        InfoTableViewCell *cell=[[InfoTableViewCell alloc]init];
        [_statusCells addObject:cell];
    }];
}
#pragma mark - 数据源方法
#pragma mark 返回分组数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

#pragma mark 返回每组行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _status.count;
}

#pragma mark返回每行的单元格
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier=@"UITableViewCellIdentifierKey1";
    InfoTableViewCell *cell;
    cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell){
        cell=[[InfoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    ItemInfo *status=_status[indexPath.row];
    cell.status=status;
    return cell;
}

#pragma mark - 代理方法
#pragma mark 重新设置单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    InfoTableViewCell *cell= _statusCells[indexPath.row];
    cell.status=_status[indexPath.row];
    return cell.height;
}

#pragma mark 重写状态样式方法
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

//点击回调函数
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ItemInfo *status = _status[indexPath.row];

    if(status.ads){
        //步骤5
        AdNative *adNative = [AdNative getAdNativeById:[status Id]];
        [adNative nativeAdsClick ];
        NSLog(@"ads");
    }else{
        NSLog(@"not ads");
    }
    
}


@end
