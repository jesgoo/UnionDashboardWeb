//
//  KCCutomCellViewController.h
//  UITableView
//
//  Created by Kenshin Cui on 14-3-1.
//  Copyright (c) 2014年 Kenshin Cui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemInfo.h"

@class InfoCellViewController;
@protocol KCStatusCellViewControllerDelegate <NSObject>
- (void)webLPController:(InfoCellViewController *)controller didFinishWithResult:(id)result;
@end


@interface InfoCellViewController : UIViewController
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, assign) id<KCStatusCellViewControllerDelegate> delegate;
@property (nonatomic, strong) UIWindow *previousWindow;
-(void) insertCell:(ItemInfo *) status at:(int)index;

@end
