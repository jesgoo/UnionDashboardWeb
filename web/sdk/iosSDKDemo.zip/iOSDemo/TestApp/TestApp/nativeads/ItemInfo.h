//
//  KCStatus.h
//  UITableView
//
//  Created by Kenshin Cui on 14-3-1.
//  Copyright (c) 2014年 Kenshin Cui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ItemInfo : NSObject

#pragma mark - 属性
@property (nonatomic,assign) NSString* Id;
@property (nonatomic,copy) NSString *profileImageUrl;//头像
@property (nonatomic,copy) NSString *userName;//发送用户
@property (nonatomic,assign) NSString *mbtype;//会员类型
@property (nonatomic,copy) NSString *createdAt;//创建时间
@property (nonatomic,copy) NSString *source;//设备来源
@property (nonatomic,copy) NSString *text;//微博内容
@property (nonatomic,copy) NSString *imgUrl;//
@property int imgW;
@property int imgH;
@property BOOL ads;



#pragma mark - 方法
#pragma mark 根据字典初始化微博对象
-(ItemInfo *)initWithDictionary:(NSDictionary *)dic;

#pragma mark 初始化微博对象（静态方法）
+(ItemInfo *)statusWithDictionary:(NSDictionary *)dic;
@end
