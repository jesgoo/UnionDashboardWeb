//
//  ViewController.m
//  TestApp
//
//  Created by Bolee on 11/4/14.
//  Copyright (c) 2014 Will. All rights reserved.
//

#import "ViewController.h"
#import "InfoCellViewController.h"
#import "ItemInfo.h"
@interface ViewController ()

@property (nonatomic, strong) UIWindow *currentController; //用户的当前window

@property (nonatomic, strong) UIWindow *tableViewWindow; //将要展示原生广告的的window
@property (nonatomic, strong) InfoCellViewController* statusHandler;//TableView的controller
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _adInterstitial = [[AdInterstitial alloc]initWithAppId:@"appid" adSlotsId:@"adslot" listener:self];
    
    
    _adView = [[AdView alloc] initWithAppId:@"appid" adSlotsId:@"adslot" frame:CGRectMake(0, 80, [UIScreen mainScreen].bounds.size.width, 50) listener:self];
    [self.view addSubview: _adView];
    
    _adInitial = [[AdInitial alloc]initWithAppId:@"appid" adSlotsId:@"adslot" controller:self listener:self];
    
    
}



- (IBAction)showInterstitial:(id)sender {
    [_adInterstitial showInterstial:self];
}


- (IBAction)showNativeAds:(id)sender {
    _currentController = [[UIApplication sharedApplication] keyWindow];
    if (_tableViewWindow == nil) {
        _tableViewWindow = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    }
    _statusHandler= [[InfoCellViewController alloc] init];;
    _tableViewWindow.rootViewController = _statusHandler;
    _statusHandler.previousWindow = _currentController;
    [_tableViewWindow makeKeyAndVisible];
    //步骤1
    _adNative = [[AdNative alloc] initWithAppId:@"appid" adSlotsId:@"adslot" listener:self forStyleType:ALL];
}

- (void)didReceiveMemoryWarning {
    
}
//插屏广告回调
- (void)interstitialFailed:(NSString *)reason{//插屏展示失败
    NSLog(@"interstitialFailed %@",reason);
}

- (void)interstitialShowed{//广告被展示通知
    NSLog(@"interstitialShowed");
}
- (void)interstitialClicked{//广告被点击通知
    NSLog(@"interstitialClicked");
}

//banner广告回调
-(void) adFailed:(NSString *)reason{//banner请求失败通知
    NSLog(@"Banner adFailed %@",reason);
}
-(void) adViewClicked{//广告被点击通知
    NSLog(@"banner Clicked");
}
-(void) adViewShowed{//广告被展示通知
    NSLog(@"banner Showed");
}

//步骤2
//原生广告回调
-(void) nativeAdsFailed:(NSString *)reason{
    NSLog(@"native ads adFailed %@",reason);
}
-(void) nativeAdsLoaded:(AdNative *)nativeAd//广告加载成功通知
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    //步骤3
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          [nativeAd getId],@"Id",
                          @"8:23",@"createdAt",
                          @"a1.png",@"mbtype",
                          [nativeAd getLogoUrl],@"profileImageUrl",
                          [nativeAd getTitle],@"source",
                          [nativeAd getDesc1],@"text",
                          [nativeAd getImgUrl],@"imgUrl",
                          [NSNumber numberWithInt:[nativeAd getWidth] ],@"w",
                          [NSNumber numberWithInt:[nativeAd getHeight]],@"h",
                          [nativeAd getAccount],@"userName",
                          [NSNumber numberWithBool:TRUE],@"ads",nil];
    NSLog(@"%@",dict);
    [array addObject:dict];
    ItemInfo * status = [ItemInfo statusWithDictionary:dict];
    [_statusHandler insertCell:status at:2];
    //步骤4
    [nativeAd nativeAdsShow];
}


//开屏广告回调


-(void) initialFailed:(NSString *)reason{
    NSLog(@"initialAds adFailed %@",reason);
}
/**
 *  广告展示时的回调
 */
- (void)initialShowed{
    NSLog(@"initialAds showed");
}
/**
 *  广告展示被用户点击时的回调
 */
- (void)initialClicked{
    NSLog(@"initialAds clicked");
}

@end
