package com.jesgoo.sdk.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.jesgoo.sdk.AdSize;
import com.jesgoo.sdk.AdView;
import com.jesgoo.sdk.AdViewListener;

public class MainActivity extends Activity implements AdViewListener {
	static AdView interstialAdView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main);
		final RelativeLayout rl = (RelativeLayout) this.findViewById(R.id.adViewParent);
		Button showInterstialBtn = (Button) this.findViewById(R.id.showInterstial);
		Button gotoNative = (Button) this.findViewById(R.id.gotoNative);
		
		AdView.preLoad(this, "apid");
		// 开屏实现方式1(SDK自带动画，无需手动添加至控件树)
		AdView init1 = new AdView(this, AdSize.Initial, "adslot");
//		init1.setListener(this);
		// 开屏实现方式2(无动画，需要开发者将adView添加到控件树)
//		final AdView init2 = new AdView(this, AdSize.InitialNoAnimation, null);
//		addContentView(init2, new FrameLayout.LayoutParams(-1,-1));
		
		// 插屏
		interstialAdView = new AdView(MainActivity.this, AdSize.Interstitial, "adslot");
//		interstialAdView.setListener(this);
		//banner
		final AdView bannerAdView = new AdView(MainActivity.this, AdSize.Banner, "adslot");
		rl.addView(bannerAdView);
		bannerAdView.setListener(this);
		OnClickListener listener = new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				switch (arg0.getId()) {

				case R.id.showInterstial:
					interstialAdView.showInterstialAd();
					break;
				case R.id.gotoNative:
					Intent intent = new Intent(MainActivity.this,NativeAdsActivity.class);
					startActivity(intent);
				default:
					break;
				}
			}
		};

		showInterstialBtn.setOnClickListener(listener);
		gotoNative.setOnClickListener(listener);

	}
	@Override
	public void onAdClick() {
		
		System.out.println("click");
	}
	@Override
	public void onAdFailed(String arg0) {
		System.out.println("failed:"+arg0);
		
	}
	@Override
	public void onAdReady(AdView arg0) {
		System.out.println("ready");
		
	}
	@Override
	public void onAdShow() {
		System.out.println("show");
		
	}
	//非原生广告，无用
	@Override
	public void onEvent(String arg0) {
	}

	
}
