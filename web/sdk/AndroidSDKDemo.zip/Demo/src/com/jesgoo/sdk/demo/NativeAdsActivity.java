package com.jesgoo.sdk.demo;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.ThumbnailUtils;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jesgoo.sdk.NativeAds;
import com.jesgoo.sdk.NativeAdsListener;

public class NativeAdsActivity extends Activity {
	private final static String itemId = "id";
	private final static String itemDesc = "desc";
	private final static String itemAccount = "account";
	private final static String itemImgUrl = "imgUrl";
	private final static String itemLogoUrl = "logoUrl";
	private final static String itemImgW = "w";
	private final static String itemImgH = "h";

	// 初始化应用的数据，方便起见，demo中直接硬编码
	private List<JSONObject> mData = new ArrayList<JSONObject>();

	private void addData() {
		try {
			JSONObject testObj0 = new JSONObject()
					.put(itemDesc, "应用数据1：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			JSONObject testObj1 = new JSONObject()
					.put(itemDesc, "应用数据2：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			JSONObject testObj2 = new JSONObject()
					.put(itemDesc, "应用数据3：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			JSONObject testObj3 = new JSONObject()
					.put(itemDesc, "应用数据4：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			JSONObject testObj4 = new JSONObject()
					.put(itemDesc, "应用数据5：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			JSONObject testObj5 = new JSONObject()
					.put(itemDesc, "应用数据6：斗地主，玩斗地主，好好玩斗地主")
					.put(itemAccount, "休闲娱乐")
					.put(itemLogoUrl,
							"http://img.wdjimg.com/mms/icon/v1/8/25/3fc1dd45eb33ae0b165e205097125258_256_256.png")
					.put(itemImgUrl, null).put(itemId, null).put("w", 0).put("h", 0);
			mData.add(testObj0);
			mData.add(testObj1);
			mData.add(testObj2);
			mData.add(testObj3);
			mData.add(testObj4);
			mData.add(testObj5);
		} catch (Exception e) {
		}
	}

	MyAdapter adapter;

	public final class ViewHolder {
		public TextView account;
		public TextView desc;
		public TextView type;
		public ImageView img;
		public ImageView logo;

	}

	private void addNativeAds(final int position) {

		// 步骤一
		NativeAds.preLoad(this, "appid");
		// 在第2个位置插入第一条广告
		// 步骤二
		final NativeAds nativeAds = new NativeAds(this, "adslot");

		// 步骤三
		nativeAds.setListener(new NativeAdsListener() {
			@Override
			public void onAdReady(JSONObject arg0) {
				// 步骤四
				try {

					mData.add(
							position,
							new JSONObject().put(itemDesc, nativeAds.getDesc1())
									.put(itemLogoUrl, nativeAds.getLogoUrl()).put(itemAccount, nativeAds.getAccount())
									.put(itemImgUrl, nativeAds.getImgUrl()).put(itemId, nativeAds.getId())
									.put(itemImgW, nativeAds.getWidth()).put(itemImgH, nativeAds.getHeight()));
					adapter.notifyDataSetChanged();
				} catch (Exception e) {
				}
				// 步骤五
				nativeAds.setAdImpression();
			}

			@Override
			public void onAdFailed(JSONObject data) {
				Toast.makeText(NativeAdsActivity.this, data.optString("info"), Toast.LENGTH_SHORT).show();
			}
		});
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addData();
		setContentView(R.layout.native_ads_layout);
		ListView listView = (ListView) findViewById(R.id.listView);

		adapter = new MyAdapter(this);
		listView.setAdapter(adapter);
		addNativeAds(2);
		addNativeAds(6);

	}

	public static Bitmap getBitmapFromURL(String src) {
		try {
			URL url = new URL(src);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoInput(true);
			connection.connect();
			InputStream input = connection.getInputStream();
			return BitmapFactory.decodeStream(input);
		} catch (IOException e) {
			Log.e("Exception", e.getMessage());
			return null;
		}
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		AsynImageLoader loader = new AsynImageLoader();

		public MyAdapter(Context context) {
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return mData.size();
		}

		@Override
		public Object getItem(int arg0) {
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			return 0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;
			try {

				final JSONObject data = mData.get(position);
				final String idString = data.optString(itemId);
				final String desc = data.optString(itemDesc);
				final String account = data.optString(itemAccount);
				final int w = data.optInt(itemImgW);
				final int h = data.optInt(itemImgH);
				final String imgUrl = data.optString(itemImgUrl);
				final String logoUrl = data.optString(itemLogoUrl);

				holder = new ViewHolder();
				if (idString != null && !idString.equals("")) {// 广告

					if (imgUrl != null && !imgUrl.equals("")) {
						convertView = mInflater.inflate(R.layout.native_ads_img_item, null);
						holder.account = (TextView) convertView.findViewById(R.id.account);
						holder.type = (TextView) convertView.findViewById(R.id.isAds);
						holder.img = (ImageView) convertView.findViewById(R.id.img);

						holder.img.setImageBitmap(loader.loadDrawableFromNet(holder.img, imgUrl));
						// System.out.println("img.height:"+holder.img.getHeight());
						holder.account.setText(account);
						holder.type.setTextColor(Color.RED);
						holder.type.setText("推广");
						convertView.setTag(holder);
					} else {

						convertView = mInflater.inflate(R.layout.native_ads_txt_item, null);
						holder.account = (TextView) convertView.findViewById(R.id.account);
						holder.desc = (TextView) convertView.findViewById(R.id.desc);
						holder.type = (TextView) convertView.findViewById(R.id.isAds);
						holder.logo = (ImageView) convertView.findViewById(R.id.logo);

						convertView.setTag(holder);

						holder.account.setText(account);
						holder.desc.setText(desc);
						if (logoUrl != null && !logoUrl.equals("")) {
							holder.logo.setImageBitmap(loader.loadDrawableFromNet(holder.logo, logoUrl));
						}
						holder.type.setTextColor(Color.RED);
						holder.type.setText("推广");
						// imgRL.setVisibility(View.GONE);
					}
				} else {
					convertView = mInflater.inflate(R.layout.native_ads_txt_item, null);
					holder.account = (TextView) convertView.findViewById(R.id.account);
					holder.desc = (TextView) convertView.findViewById(R.id.desc);
					holder.type = (TextView) convertView.findViewById(R.id.isAds);
					holder.logo = (ImageView) convertView.findViewById(R.id.logo);

					holder.desc.setText(desc);
					holder.account.setText(account);
					holder.desc.setText(desc);
					holder.logo.setImageBitmap(loader.loadDrawableFromNet(holder.logo, logoUrl));
					convertView.setTag(holder);
				}

				convertView.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// 步骤六
						NativeAds nativeAds = NativeAds.getNativeAds(idString);
						if (nativeAds != null) {
							nativeAds.setAdClick();
						}

					}
				});
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			return convertView;
		}

	}

	interface LoadCallBack {
		public Bitmap load(String uri);
	}

	class AsynImageLoader {

		// 图片软引用
		private HashMap<String, SoftReference<Bitmap>> imageCache;
		// 显示图片的ImageView
		private HashMap<String, ImageView> imageViews;

		public AsynImageLoader() {// 构造
			imageCache = new HashMap<String, SoftReference<Bitmap>>();
			imageViews = new HashMap<String, ImageView>();
		}

		/**
		 * 从网络上获取图片
		 * 
		 * @param imageView
		 *            显示图片的ImageView
		 * @param imageUrl
		 *            图片的地址
		 * @return 图片
		 */
		public Bitmap loadDrawableFromNet(final ImageView imageView, final String imageUrl) {
			return loadDrawable(imageView, imageUrl, new LoadCallBack() {
				public Bitmap load(String uri) {
					return loadImageFromNet(uri);
				}
			});
		}

		/**
		 * 获取图片
		 * 
		 * @param imageView
		 *            显示图片的ImageView
		 * @param imageUrl
		 *            图片路径或网络地址
		 * @param load
		 *            回调方法 加载本地图片或者加载网络图片
		 * @return
		 */
		private Bitmap loadDrawable(final ImageView imageView, final String imageUrl, final LoadCallBack load) {
			final String key = imageUrl + imageView.toString();
			// 判断软引用里是否有图片
			if (imageCache.containsKey(imageUrl)) {
				SoftReference<Bitmap> softReference = imageCache.get(imageUrl);
				Bitmap bitmap = softReference.get();
				if (bitmap != null) {
					return bitmap;// 有则返回
				}
			}

			// 将为添加到图片显示集合的 ImageViwe 加入到集合
			if (!imageViews.containsKey(key)) {
				imageViews.put(key, imageView);
			}

			final Handler handler = new Handler() {
				public void handleMessage(Message message) {
					ImageView imageView = imageViews.get(key);
					imageView.setImageBitmap((Bitmap) message.obj);
				}
			};

			// 启动线程获取图片
			new Thread() {
				public void run() {
					Bitmap bitmap = load.load(imageUrl);// 执行回调

					DisplayMetrics displayMetrics = new DisplayMetrics();
					((WindowManager) imageView.getContext().getApplicationContext()
							.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(displayMetrics);
					imageCache.put(imageUrl, new SoftReference<Bitmap>(bitmap));
					Message message = handler.obtainMessage(0, bitmap);
					handler.sendMessage(message);
				}
			}.start();
			return null;
		}

		/**
		 * 从网络加载图片
		 * 
		 * @param url
		 * @return
		 */
		public Bitmap loadImageFromNet(String url) {
			URL m;
			InputStream i = null;
			try {
				m = new URL(url);
				i = (InputStream) m.getContent();
			} catch (MalformedURLException e1) {
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return BitmapFactory.decodeStream(i);
		}

	}
}